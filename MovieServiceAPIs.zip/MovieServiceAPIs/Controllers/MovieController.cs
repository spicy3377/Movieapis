using Microsoft.AspNetCore.Mvc;

namespace MovieServiceAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MoviesController : ControllerBase
{
    private readonly MovieService _movieService;

    public MoviesController(MovieService movieService)
    {
        _movieService = movieService;
    }

    [HttpGet("search")]
    public async Task<ActionResult<MovieSearchResult>> SearchMovies([FromQuery] string title)
    {
        var searchResult = await _movieService.SearchMoviesAsync(title);
        return Ok(searchResult);
    }

    [HttpGet("details")]
    public async Task<ActionResult<MovieDetails>> GetMovieDetails([FromQuery] string imdbId)
    {
        var details = await _movieService.GetMovieDetailsAsync(imdbId);
        return Ok(details);
    }
}