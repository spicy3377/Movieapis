using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MovieServiceAPI.Controllers
{
    public class MovieService
    {
        private readonly string _apiKey;
        private readonly HttpClient _httpClient;

        public MovieService(string apiKey)
        {
            _apiKey = apiKey;
            _httpClient = new HttpClient();
        }

        public async Task<MovieSearchResult> SearchMoviesAsync(string title)
        {
            string apiUrl = $"http://www.omdbapi.com/?apikey={_apiKey}&t={title}&plot=full";

            HttpResponseMessage response = await _httpClient.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                MovieSearchResult result = JsonConvert.DeserializeObject<MovieSearchResult>(content);
                return result;
            }

            // Handle the case when the request fails
            return null;
        }

        public async Task<MovieDetails> GetMovieDetailsAsync(string imdbId)
        {
            string apiUrl = $"http://www.omdbapi.com/?apikey={_apiKey}&i={imdbId}&plot=full";

            HttpResponseMessage response = await _httpClient.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                MovieDetails details = JsonConvert.DeserializeObject<MovieDetails>(content);
                return details;
            }

            // Handle the case when the request fails
            return null;
        }
    }
}
