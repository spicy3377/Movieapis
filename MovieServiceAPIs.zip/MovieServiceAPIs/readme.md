run this command in your project directory if you want to test

dotnet add package Newtonsoft.Json

and dotnet run