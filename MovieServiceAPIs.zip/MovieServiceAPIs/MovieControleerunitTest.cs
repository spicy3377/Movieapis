// MoviesControllerTests.cs
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using YourNamespace.Controllers;
using YourNamespace.Models;  // Import your models
using YourNamespace.Services;  // Import your services

public class MoviesControllerTests
{
    [Fact]
    public async Task SearchMovies_ReturnsOkResult()
    {
        // Arrange
        var mockMovieService = new Mock<MovieService>();
        mockMovieService.Setup(service => service.SearchMoviesAsync(It.IsAny<string>()))
            .ReturnsAsync(new MovieSearchResult());  // Adjust the response based on your actual implementation

        var controller = new MoviesController(mockMovieService.Object);

        // Act
        var result = await controller.SearchMovies("Inception");

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var model = Assert.IsAssignableFrom<MovieSearchResult>(okResult.Value);
        Assert.NotNull(model);
    }

    // Add more tests for other controller actions
}
