﻿namespace MovieFinder.Domain.Entities;
public class SearchData
{
    public IEnumerable<Movie> Results { get; set; }
}
