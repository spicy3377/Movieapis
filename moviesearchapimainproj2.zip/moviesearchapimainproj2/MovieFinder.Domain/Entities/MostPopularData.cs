﻿namespace MovieFinder.Domain.Entities;
public class MostPopularData
{
    public List<MostPopularDataDetail> Items { get; set; }
}
