MovieFinder Application
========================

This is a movie search application built with .NET Core Web API and React, styled with Material UI. 

Users can search for movies and view details about each movie.


### Prerequisites

-   Node.js v12.x or higher
-   .NET Core SDK v6 or higher
