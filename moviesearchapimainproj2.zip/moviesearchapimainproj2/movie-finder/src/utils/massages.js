export const connectionErrorMassage = <>
    Something went wrong..
    <br />
    <br />
    Please check your internet connection
    <br />
    and try again
</>

export const notFoundErrorMassage = <>
    No results for this movie..
    <br />
    <br />
    Please try again.
</>
